# Tarek Memo (Android Studio project)

Black & Gold Android starter app for local memo and daily accounts.

## Included in v1
- Local SQLite storage on the phone
- Sales memo: customer, phone, product, quantity, sale rate, purchase cost, paid amount
- Automatic total and due calculation
- Monthly sales, collected amount, due, expense and estimated profit summary
- Daily expense entry
- Memo history

## Build an APK
1. Install Android Studio on a computer.
2. Open this `TarekMemo` folder in Android Studio.
3. Let Gradle sync complete (internet is needed for the first dependency download).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

## Important notes
- Data is stored locally in the app's SQLite database. Uninstalling the app or clearing its storage deletes the data.
- This starter version does not yet include PDF/image sharing, memo editing/deleting, multi-product rows, or backup/export. Those are planned next.
- Profit is an estimate: enter the purchase cost per unit accurately. Monthly expenses are subtracted from gross product margin.
- Currency is shown in BDT (৳).
