package com.tarekmemo.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFD6B45C)
private val Black = Color(0xFF121212)
private val Panel = Color(0xFF222222)
private val Muted = Color(0xFFBDBDBD)

data class Memo(val id: Long, val customer: String, val phone: String, val product: String,
                val qty: Double, val rate: Double, val cost: Double, val total: Double,
                val paid: Double, val date: String) {
    val due: Double get() = total - paid
    val profit: Double get() = total - (qty * cost)
}

class MemoDb(ctx: Context) : SQLiteOpenHelper(ctx, "tarek_memo.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE memos(
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, phone TEXT, product TEXT,
            qty REAL, rate REAL, cost REAL, total REAL, paid REAL, date TEXT)""")
        db.execSQL("""CREATE TABLE expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount REAL, date TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addMemo(m: Memo) {
        val v = ContentValues().apply {
            put("customer",m.customer); put("phone",m.phone); put("product",m.product)
            put("qty",m.qty); put("rate",m.rate); put("cost",m.cost); put("total",m.total)
            put("paid",m.paid); put("date",m.date)
        }
        writableDatabase.insert("memos", null, v)
    }
    fun allMemos(): List<Memo> {
        val out = mutableListOf<Memo>()
        readableDatabase.rawQuery("SELECT * FROM memos ORDER BY id DESC", null).use { c ->
            while(c.moveToNext()) out.add(Memo(c.getLong(0),c.getString(1),c.getString(2),
                c.getString(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getDouble(7),
                c.getDouble(8),c.getString(9)))
        }
        return out
    }
    fun addExpense(title: String, amount: Double) {
        val v = ContentValues().apply {
            put("title",title); put("amount",amount)
            put("date", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()))
        }
        writableDatabase.insert("expenses", null, v)
    }
    fun expenseTotal(month: String): Double {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date LIKE ?",
            arrayOf("$month%")).use { c -> if(c.moveToFirst()) return c.getDouble(0) }
        return 0.0
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = MemoDb(this)
        setContent { TarekMemoApp(db) }
    }
}

@Composable
fun TarekMemoApp(db: MemoDb) {
    var tab by remember { mutableStateOf(0) }
    var memos by remember { mutableStateOf(db.allMemos()) }
    var showNew by remember { mutableStateOf(false) }
    var showExpense by remember { mutableStateOf(false) }
    val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    val monthly = memos.filter { it.date.startsWith(month) }
    val sales = monthly.sumOf { it.total }
    val collected = monthly.sumOf { it.paid }
    val due = monthly.sumOf { it.due }
    val expenses = db.expenseTotal(month)
    val profit = monthly.sumOf { it.profit } - expenses

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Black, background = Black, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Black, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Gold) {
                NavigationBarItem(selected=tab==0,onClick={tab=0},icon={},label={Text("হোম")})
                NavigationBarItem(selected=tab==1,onClick={tab=1},icon={},label={Text("মেমো")})
                NavigationBarItem(selected=tab==2,onClick={tab=2},icon={},label={Text("হিসাব")})
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
                Text("TAREK MEMO", color=Gold, fontSize=26.sp, fontWeight=FontWeight.Black)
                Text("SMART BUSINESS MANAGER", color=Muted, fontSize=10.sp, letterSpacing=2.sp)
                Spacer(Modifier.height(18.dp))
                when(tab) {
                    0 -> {
                        Text("এই মাসের সারাংশ", color=Gold, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        SummaryCard("মোট বিক্রি", sales)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)){ SummaryCard("আদায়", collected) }
                            Box(Modifier.weight(1f)){ SummaryCard("বাকি", due) }
                        }
                        SummaryCard("আনুমানিক লাভ (খরচ বাদে)", profit)
                        Spacer(Modifier.height(12.dp))
                        ButtonGold("＋ নতুন Sales Memo") { showNew=true }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick={showExpense=true}, modifier=Modifier.fillMaxWidth(),
                            colors=ButtonDefaults.outlinedButtonColors(contentColor=Gold)) {
                            Text("＋ দৈনিক খরচ যোগ")
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("সাম্প্রতিক মেমো", color=Gold, fontWeight=FontWeight.Bold)
                        MemoList(memos.take(4))
                    }
                    1 -> {
                        Row(horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) {
                            Text("সব মেমো", color=Gold, fontSize=20.sp, fontWeight=FontWeight.Bold)
                            Text("＋ নতুন", color=Gold, modifier=Modifier.clickable { showNew=true })
                        }
                        MemoList(memos)
                    }
                    else -> {
                        Text("মাসিক হিসাব", color=Gold, fontSize=20.sp, fontWeight=FontWeight.Bold)
                        Text(month, color=Muted)
                        SummaryCard("মোট বিক্রি", sales)
                        SummaryCard("মোট আদায়", collected)
                        SummaryCard("মোট বাকি", due)
                        SummaryCard("দৈনিক খরচ (মাস)", expenses)
                        SummaryCard("আনুমানিক লাভ", profit)
                        Text("লাভের হিসাব পণ্যের ক্রয়মূল্য দেওয়া থাকলে নির্ভরযোগ্য হবে।",
                            color=Muted, fontSize=11.sp)
                    }
                }
            }
        }
        if(showNew) NewMemoDialog(onDismiss={showNew=false}, onSave={ m ->
            db.addMemo(m); memos=db.allMemos(); showNew=false
        })
        if(showExpense) ExpenseDialog(onDismiss={showExpense=false}, onSave={ title, amount ->
            db.addExpense(title,amount); showExpense=false
        })
    }
}

@Composable
fun SummaryCard(label: String, amount: Double) {
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp), colors=CardDefaults.cardColors(containerColor=Panel),
        shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color=Muted, fontSize=12.sp)
            Text("৳ ${"%.2f".format(Locale.US,amount)}", color=Gold, fontSize=21.sp,
                fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
fun ButtonGold(text: String, onClick: () -> Unit) {
    Button(onClick=onClick, modifier=Modifier.fillMaxWidth(),
        colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Black)) {
        Text(text, fontWeight=FontWeight.Bold)
    }
}

@Composable
fun MemoList(memos: List<Memo>) {
    if(memos.isEmpty()) {
        Text("এখনো কোনো মেমো নেই। নতুন মেমো তৈরি করুন।", color=Muted,
            modifier=Modifier.padding(vertical=18.dp))
    } else {
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(memos) { m ->
                Card(colors=CardDefaults.cardColors(containerColor=Panel), modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.customer.ifBlank { "নাম দেওয়া হয়নি" }, color=Gold, fontWeight=FontWeight.Bold)
                        Text("${m.product}  •  ${m.date}", color=Muted, fontSize=12.sp)
                        Text("মোট ৳ ${"%.2f".format(Locale.US,m.total)}   |   বাকি ৳ ${"%.2f".format(Locale.US,m.due)}",
                            color=Color.White, fontSize=13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String)->Unit, numeric: Boolean=false) {
    OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},
        modifier=Modifier.fillMaxWidth(), singleLine=true,
        keyboardOptions=KeyboardOptions(keyboardType=if(numeric) KeyboardType.Decimal else KeyboardType.Text),
        colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Gold, focusedLabelColor=Gold,
            cursorColor=Gold, unfocusedTextColor=Color.White, focusedTextColor=Color.White))
}

@Composable
fun NewMemoDialog(onDismiss:()->Unit, onSave:(Memo)->Unit) {
    var customer by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var product by remember { mutableStateOf("") }; var qty by remember { mutableStateOf("1") }
    var rate by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    val total=(qty.toDoubleOrNull()?:0.0)*(rate.toDoubleOrNull()?:0.0)
    AlertDialog(onDismissRequest=onDismiss, containerColor=Panel,
        title={Text("নতুন Sales Memo",color=Gold)},
        text={
            Column(Modifier.heightIn(max=500.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Field("Customer Name",customer,{customer=it})
                Field("Mobile Number",phone,{phone=it},true)
                Field("Product Name",product,{product=it})
                Field("Quantity",qty,{qty=it},true)
                Field("প্রতি পিস বিক্রয় মূল্য",rate,{rate=it},true)
                Field("প্রতি পিস ক্রয় মূল্য (লাভের জন্য)",cost,{cost=it},true)
                Field("জমা টাকা",paid,{paid=it},true)
                Text("মোট: ৳ ${"%.2f".format(Locale.US,total)}  |  বাকি: ৳ ${"%.2f".format(Locale.US,total-(paid.toDoubleOrNull()?:0.0))}",
                    color=Gold, fontWeight=FontWeight.Bold)
            }
        },
        confirmButton={ TextButtonGold("Save") {
            if(product.isNotBlank() && total>0) onSave(Memo(0,customer,phone,product,
                qty.toDoubleOrNull()?:0.0,rate.toDoubleOrNull()?:0.0,cost.toDoubleOrNull()?:0.0,
                total,paid.toDoubleOrNull()?:0.0,SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())))
        }},
        dismissButton={ TextButton(onClick=onDismiss){Text("Cancel",color=Muted)} })
}

@Composable
fun TextButtonGold(text:String,onClick:()->Unit) {
    Text(text,color=Gold,fontWeight=FontWeight.Bold,modifier=Modifier.clickable { onClick() }.padding(10.dp))
}

@Composable
fun ExpenseDialog(onDismiss:()->Unit,onSave:(String,Double)->Unit) {
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,containerColor=Panel,title={Text("দৈনিক খরচ",color=Gold)},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Field("খরচের বিবরণ",title,{title=it})
            Field("টাকার পরিমাণ",amount,{amount=it},true)
        }},
        confirmButton={TextButtonGold("Save"){ val a=amount.toDoubleOrNull()?:0.0
            if(title.isNotBlank()&&a>0) onSave(title,a) }},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel",color=Muted)}})
}
